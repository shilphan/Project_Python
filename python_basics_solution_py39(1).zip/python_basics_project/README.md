# Python Basics Lab

A hands-on Python project that teaches the fundamentals one topic at a time, then
combines them all in a capstone **Student Gradebook**. Every module has a runnable
`demo()` that prints annotated examples, plus small functions you can import and test.

Requires **Python 3.9 or newer** (tested on 3.9 and 3.13). No third-party packages.

## Run it

```bash
python main.py          # interactive menu
python main.py --all    # run every demo in order
python basics.py        # or run any single module on its own
python -m unittest discover tests -v    # run the 48 tests
```

## What is covered

| # | Topic | File | Key ideas |
|---|-------|------|-----------|
| 1 | Basics | `basics.py` | variables, data types, arithmetic operators, type conversion, f-string formatting |
| 2 | Selection statements | `selection.py` | `if / elif / else`, `and / or / not`, ternary, `in` membership tests, truthiness |
| 3 | Loops | `loops.py` | `for`, `while`, `range`, `enumerate`, `break`, `continue`, `for/else`, nested loops |
| 4 | Functions | `functions.py` | defaults, keyword args, `*args`, `**kwargs`, recursion, closures, `lambda`, scope |
| 5 | Lists | `lists_demo.py` | indexing, slicing, methods, comprehensions, sorting, copy vs alias |
| 6 | Strings | `strings_demo.py` | slicing, methods, `split` / `join`, formatting, palindromes, Caesar cipher |
| 7 | Multidimensional lists | `matrix.py` | 2-D grids, nested loops, transpose, multiplication, 3-D lists, the shared-row trap |
| 8 | Capstone | `gradebook.py` | uses all of the above in one program |

Supporting files: `utils.py` (banner and safe input helpers), `main.py` (menu), `tests/test_all.py`.

## The capstone

`gradebook.py` stores scores in a 2-D list (one row per student, one column per subject) and uses:

- **matrix** helpers for row and column totals
- **selection** for letter grades and input validation
- **loops** and **strings** to build an aligned report table
- **functions** and **lists** to find the top student, weakest subject and grade distribution

Choose `g` in the menu to add your own students interactively.

## Suggested way to learn

1. Run a topic's demo and read the output next to the source.
2. Change a value in the demo and predict the output before re-running.
3. Try the exercises below, then check your idea against the tests.

## Exercises

- **Basics:** write `fahrenheit_to_celsius` and a compound-interest calculator.
- **Selection:** add a `ticket_price(age)` function with child, adult and senior bands.
- **Loops:** print a pyramid, find all perfect numbers below 1000, or check for Armstrong numbers.
- **Functions:** write `compose(f, g)` and a recursive `gcd(a, b)`.
- **Lists:** merge two sorted lists without using `sort()`.
- **Strings:** write a function that checks whether a password has upper, lower, digit and symbol.
- **Multidimensional lists:** detect a winner in connect-four, or print Pascal's triangle with nested lists.
- **Capstone:** add a "drop lowest score" option, save the gradebook to a CSV file, or sort the report by average.

## Project layout

```
python_basics_project/
├── main.py
├── utils.py
├── basics.py
├── selection.py
├── loops.py
├── functions.py
├── lists_demo.py
├── strings_demo.py
├── matrix.py
├── gradebook.py
├── tests/
│   └── test_all.py
└── README.md
```
