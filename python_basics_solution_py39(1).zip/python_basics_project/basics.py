"""Topic 1 - Python basics: variables, data types, operators, input and output."""

from utils import header


def celsius_to_fahrenheit(celsius):
    """Convert a temperature from Celsius to Fahrenheit."""
    return celsius * 9 / 5 + 32


def bmi(weight_kg, height_m):
    """Body-mass index = weight / height squared."""
    return weight_kg / height_m ** 2


def simple_interest(principal, rate_percent, years):
    """Interest earned without compounding."""
    return principal * rate_percent * years / 100


def fahrenheit_to_celsius(fahrenheit):
    """Convert a temperature from Fahrenheit to Celsius."""
    return (fahrenheit - 32) * 5 / 9


def compound_interest(principal, rate_percent, years, times_per_year=1):
    """Final amount (principal plus interest) when interest is compounded."""
    rate = rate_percent / 100 / times_per_year
    return principal * (1 + rate) ** (times_per_year * years)


def demo():
    header("1. BASICS: variables, types, operators")

    # --- Variables and data types -------------------------------------
    print("Data types:")
    for value in ("Python", 3.13, 42, True, None):
        print(f"  {value!r:<10} has type {type(value).__name__}")

    # --- Arithmetic operators -----------------------------------------
    a, b = 17, 5
    print(f"\nArithmetic with a={a}, b={b}:")
    print(f"  a + b  = {a + b}")
    print(f"  a - b  = {a - b}")
    print(f"  a * b  = {a * b}")
    print(f"  a / b  = {a / b}     (true division, always a float)")
    print(f"  a // b = {a // b}       (floor division)")
    print(f"  a % b  = {a % b}       (remainder)")
    print(f"  a ** b = {a ** b}  (power)")

    # --- Augmented assignment and swapping ----------------------------
    total = 10
    total += 5
    total *= 2
    print(f"\nAugmented assignment: 10 += 5, *= 2 gives {total}")
    x, y = 1, 2
    x, y = y, x
    print(f"Swap without a temp variable: x={x}, y={y}")

    # --- Type conversion ----------------------------------------------
    print("\nType conversion:")
    print(f"  int('42') + 1   = {int('42') + 1}")
    print(f"  float('3.5')    = {float('3.5')}")
    print(f"  int(7.9)        = {int(7.9)}   (truncates, does not round)")
    print(f"  round(7.9)      = {round(7.9)}")
    print(f"  str(10) + '!'   = {str(10) + '!'}")
    print(f"  bool(0), bool('') -> {bool(0)}, {bool('')}   (empty/zero is False)")

    # --- Formatted output with f-strings ------------------------------
    print("\nf-string formatting:")
    print(f"  {3.14159:.2f}   two decimal places")
    print(f"  {1234567:,}   thousands separator")
    print(f"  {0.256:.1%}   percentage")
    print(f"  {42:05d}   zero padded")
    print(f"  {'left':<8}|{'right':>8}|{'mid':^8}|   alignment")

    # --- Putting it together ------------------------------------------
    print("\nSmall calculations:")
    print(f"  36.6 C  = {celsius_to_fahrenheit(36.6):.1f} F")
    print(f"  BMI of 70 kg at 1.75 m = {bmi(70, 1.75):.1f}")
    print(f"  Interest on 1000 at 5% for 3 years = {simple_interest(1000, 5, 3):.2f}")


if __name__ == "__main__":
    demo()
