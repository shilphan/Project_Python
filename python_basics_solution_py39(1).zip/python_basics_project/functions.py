"""Topic 4 - Functions: parameters, defaults, *args / **kwargs, recursion, lambda."""

from utils import header


def greet(name, greeting="Hello", punctuation="!"):
    """Default parameter values."""
    return f"{greeting}, {name}{punctuation}"


def average(*numbers):
    """*args collects any number of positional arguments into a tuple."""
    if not numbers:
        raise ValueError("average() needs at least one number")
    return sum(numbers) / len(numbers)


def describe(**details):
    """**kwargs collects keyword arguments into a dict."""
    return ", ".join(f"{key}={value}" for key, value in sorted(details.items()))


def min_max(values):
    """Return several values at once (really one tuple)."""
    return min(values), max(values)


def factorial_recursive(n):
    """A function that calls itself, with a base case."""
    if n < 0:
        raise ValueError("negative input")
    if n <= 1:
        return 1
    return n * factorial_recursive(n - 1)


def power(base, exponent=2):
    """Raise base to exponent (squares by default)."""
    return base ** exponent


def compose(f, g):
    """Return a new function that computes f(g(x))."""
    return lambda x: f(g(x))


def gcd(a, b):
    """Greatest common divisor using Euclid's algorithm (recursive)."""
    if b == 0:
        return abs(a)
    return gcd(b, a % b)


def make_multiplier(factor):
    """Closure: the inner function remembers `factor`."""
    def multiply(x):
        return x * factor
    return multiply


def apply_twice(func, value):
    """Higher-order function: functions can be passed around like data."""
    return func(func(value))


def counter_demo():
    """Local vs global scope."""
    count = 0  # local to this function

    def increment():
        nonlocal count
        count += 1
        return count

    return [increment(), increment(), increment()]


def demo():
    header("4. FUNCTIONS")

    print("Default arguments and keyword arguments:")
    print("  ", greet("Asha"))
    print("  ", greet("Ben", greeting="Welcome"))
    print("  ", greet(punctuation="?", name="Chen"))

    print("\n*args and **kwargs:")
    print(f"  average(4, 8, 15, 16, 23, 42) = {average(4, 8, 15, 16, 23, 42):.2f}")
    print(f"  describe(name='Asha', age=21) -> {describe(name='Asha', age=21)}")

    print("\nReturning multiple values (tuple unpacking):")
    low, high = min_max([7, 3, 9, 1, 5])
    print(f"  min_max([7,3,9,1,5]) -> low={low}, high={high}")

    print("\nRecursion:")
    print(f"  factorial_recursive(5) = {factorial_recursive(5)}")

    print("\nFunctions as values:")
    triple = make_multiplier(3)
    print(f"  make_multiplier(3)(10) = {triple(10)}")
    print(f"  apply_twice(triple, 2) = {apply_twice(triple, 2)}")

    print("\nlambda (small anonymous functions):")
    square = lambda x: x * x
    print(f"  square(9) = {square(9)}")
    words = ["pear", "fig", "banana", "kiwi"]
    print(f"  sorted by length: {sorted(words, key=lambda w: len(w))}")
    print(f"  map squares:      {list(map(square, [1, 2, 3, 4]))}")
    print(f"  filter evens:     {list(filter(lambda n: n % 2 == 0, range(10)))}")

    print("\nScope with nonlocal:")
    print(f"  counter_demo() -> {counter_demo()}")

    print("\nDocstrings travel with the function:")
    print(f"  greet.__doc__ = {greet.__doc__!r}")


if __name__ == "__main__":
    demo()
