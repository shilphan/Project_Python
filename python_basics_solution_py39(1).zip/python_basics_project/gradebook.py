"""Capstone - Student Gradebook.

Uses every topic in the project:
  basics        variables, arithmetic, f-strings
  selection     grade letters, validation (if / elif / else)
  loops         for / while over students and subjects
  functions     small reusable helpers
  lists         names and subjects
  strings       formatting, split(), strip(), title()
  2-D lists     the score table: one row per student, one column per subject
"""

from matrix import col_sums, row_sums
from selection import grade_letter
from utils import ask_int, header, safe_input

SUBJECTS = ["Math", "Science", "English", "History"]
STUDENTS = ["Asha", "Ben", "Chen", "Divya", "Ethan"]
SCORES = [
    [88, 92, 79, 85],
    [67, 58, 72, 64],
    [95, 98, 91, 89],
    [74, 81, 86, 90],
    [45, 52, 60, 38],
]


def student_average(row):
    """Average of one student's marks, rounded to 1 decimal place."""
    return round(sum(row) / len(row), 1)


def class_subject_averages(scores):
    """Average per subject (column), reusing col_sums from the matrix module."""
    return [round(total / len(scores), 1) for total in col_sums(scores)]


def top_student(names, scores):
    """(name, average) of the best student."""
    averages = [student_average(row) for row in scores]
    best = averages.index(max(averages))
    return names[best], averages[best]


def validate_marks(marks, subject_count):
    """Raise ValueError unless there is one 0-100 mark per subject."""
    if len(marks) != subject_count:
        raise ValueError(f"expected {subject_count} marks, got {len(marks)}")
    for mark in marks:
        if not 0 <= mark <= 100:
            raise ValueError(f"mark {mark} is outside 0-100")


def add_student(names, scores, subjects, name, marks):
    """Append a new student (in place) after validating the input."""
    name = name.strip().title()
    if not name:
        raise ValueError("name cannot be empty")
    if name.lower() in [n.lower() for n in names]:
        raise ValueError(f"{name} is already in the gradebook")
    validate_marks(marks, len(subjects))
    names.append(name)
    scores.append(list(marks))


def build_report(names, scores, subjects):
    """Return the whole gradebook as one formatted string."""
    name_width = max(len(n) for n in names + ["Class avg"]) + 2
    lines = []
    head = f"{'Student':<{name_width}}" + "".join(f"{s:>9}" for s in subjects)
    head += f"{'Average':>9}{'Grade':>7}"
    lines.append(head)
    lines.append("-" * len(head))

    totals = row_sums(scores)
    for name, row, total in zip(names, scores, totals):
        avg = round(total / len(row), 1)
        line = f"{name:<{name_width}}" + "".join(f"{mark:>9}" for mark in row)
        line += f"{avg:>9.1f}{grade_letter(avg):>7}"
        lines.append(line)

    lines.append("-" * len(head))
    subject_avgs = class_subject_averages(scores)
    overall = round(sum(subject_avgs) / len(subject_avgs), 1)
    footer = f"{'Class avg':<{name_width}}" + "".join(f"{a:>9.1f}" for a in subject_avgs)
    footer += f"{overall:>9.1f}{grade_letter(overall):>7}"
    lines.append(footer)
    return "\n".join(lines)


def summary_lines(names, scores, subjects):
    """A few headline facts about the class."""
    best_name, best_avg = top_student(names, scores)
    subject_avgs = class_subject_averages(scores)
    hardest = subjects[subject_avgs.index(min(subject_avgs))]
    easiest = subjects[subject_avgs.index(max(subject_avgs))]
    averages = [student_average(row) for row in scores]
    failing = [n for n, a in zip(names, averages) if grade_letter(a) == "F"]
    return [
        f"Top student:     {best_name} ({best_avg})",
        f"Strongest subject: {easiest} ({max(subject_avgs)})",
        f"Weakest subject:   {hardest} ({min(subject_avgs)})",
        f"Needs support:   {', '.join(failing) if failing else 'nobody'}",
    ]


def grade_distribution(scores):
    """Count of each letter grade across all individual marks."""
    counts = {letter: 0 for letter in "ABCDF"}
    for row in scores:
        for mark in row:
            counts[grade_letter(mark)] += 1
    return counts


def demo():
    header("8. CAPSTONE: STUDENT GRADEBOOK")
    print(build_report(STUDENTS, SCORES, SUBJECTS))
    print()
    for line in summary_lines(STUDENTS, SCORES, SUBJECTS):
        print(line)
    print("\nGrade distribution across all marks:")
    for letter, count in grade_distribution(SCORES).items():
        print(f"  {letter}: {'#' * count} {count}")


def interactive():
    """Menu loop: view the report or add students. Works on copies of the data."""
    names = list(STUDENTS)
    scores = [list(row) for row in SCORES]
    header("INTERACTIVE GRADEBOOK")
    while True:
        print("\n1) Show report   2) Add student   3) Class summary   0) Back")
        choice = ask_int("Choose: ", 0, 3)
        if choice is None or choice == 0:
            break
        if choice == 1:
            print(build_report(names, scores, SUBJECTS))
        elif choice == 2:
            name = safe_input("Student name: ", "") or ""
            raw = safe_input(f"Marks for {', '.join(SUBJECTS)} (separated by spaces): ", "") or ""
            try:
                marks = [int(part) for part in raw.split()]
                add_student(names, scores, SUBJECTS, name, marks)
                print(f"Added {name.strip().title()}.")
            except ValueError as error:
                print(f"Could not add student: {error}")
        else:
            for line in summary_lines(names, scores, SUBJECTS):
                print(line)


if __name__ == "__main__":
    demo()
