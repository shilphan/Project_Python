"""Topic 5 - Lists: indexing, slicing, methods, comprehensions, sorting."""

from utils import header


def remove_duplicates(items):
    """Remove repeats but keep the original order."""
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def second_largest(numbers):
    """Second largest *distinct* value, or None if there isn't one."""
    distinct = sorted(set(numbers))
    return distinct[-2] if len(distinct) >= 2 else None


def rotate_left(items, k):
    """Move the first k items to the end."""
    if not items:
        return []
    k %= len(items)
    return items[k:] + items[:k]


def merge_sorted(a, b):
    """Merge two sorted lists into one sorted list without calling sort()."""
    merged = []
    i = j = 0
    while i < len(a) and j < len(b):
        if a[i] <= b[j]:
            merged.append(a[i])
            i += 1
        else:
            merged.append(b[j])
            j += 1
    merged.extend(a[i:])
    merged.extend(b[j:])
    return merged


def running_total(numbers):
    """Cumulative sums: [1, 2, 3] -> [1, 3, 6]."""
    total = 0
    totals = []
    for n in numbers:
        total += n
        totals.append(total)
    return totals


def frequency(items):
    """Count occurrences with a dict."""
    counts = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    return counts


def chunk(items, size):
    """Split a list into pieces of at most `size` items."""
    return [items[i:i + size] for i in range(0, len(items), size)]


def bubble_sort(numbers):
    """Sort a copy of the list by repeatedly swapping neighbours."""
    data = list(numbers)
    for end in range(len(data) - 1, 0, -1):
        swapped = False
        for i in range(end):
            if data[i] > data[i + 1]:
                data[i], data[i + 1] = data[i + 1], data[i]
                swapped = True
        if not swapped:
            break
    return data


def demo():
    header("5. LISTS")

    nums = [10, 20, 30, 40, 50]
    print("Indexing and slicing on", nums)
    print(f"  nums[0]={nums[0]}  nums[-1]={nums[-1]}")
    print(f"  nums[1:4]={nums[1:4]}  nums[::2]={nums[::2]}  nums[::-1]={nums[::-1]}")

    print("\nChanging a list:")
    fruits = ["apple", "banana"]
    fruits.append("cherry")
    fruits.insert(1, "blueberry")
    fruits.extend(["date", "elderberry"])
    print("  after append / insert / extend:", fruits)
    fruits.remove("banana")
    last = fruits.pop()
    print(f"  after remove('banana') and pop() -> popped {last!r}: {fruits}")
    fruits[0] = "apricot"
    print("  after item assignment:", fruits)

    print("\nUseful built-ins on", nums)
    print(f"  len={len(nums)} sum={sum(nums)} min={min(nums)} max={max(nums)}")
    print(f"  30 in nums: {30 in nums}   nums.index(30) = {nums.index(30)}")

    print("\nSorting:")
    messy = [5, 2, 9, 1, 7]
    print("  sorted(messy)             ->", sorted(messy), "(new list)")
    print("  sorted(..., reverse=True) ->", sorted(messy, reverse=True))
    messy.sort()
    print("  messy.sort() changed it   ->", messy)
    print("  bubble_sort([5,2,9,1,7])  ->", bubble_sort([5, 2, 9, 1, 7]))

    print("\nList comprehensions:")
    print("  squares:        ", [n * n for n in range(1, 8)])
    print("  even squares:   ", [n * n for n in range(1, 11) if n % 2 == 0])
    print("  upper-cased:    ", [f.upper() for f in ["fig", "plum"]])

    print("\nProblem-solving helpers:")
    data = [4, 1, 4, 2, 9, 9, 3]
    print("  data                 =", data)
    print("  remove_duplicates    =", remove_duplicates(data))
    print("  second_largest       =", second_largest(data))
    print("  rotate_left(data, 2) =", rotate_left(data, 2))
    print("  running_total        =", running_total(data))
    print("  frequency            =", frequency(data))
    print("  chunk(data, 3)       =", chunk(data, 3))

    print("\nCopy gotcha:")
    original = [1, 2, 3]
    alias = original          # same list, two names
    clone = original.copy()   # a real copy
    alias.append(99)
    print(f"  original={original} (changed via alias)   clone={clone} (unchanged)")


if __name__ == "__main__":
    demo()
