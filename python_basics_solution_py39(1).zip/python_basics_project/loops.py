"""Topic 3 - Loops: for, while, range, break / continue, nested loops."""

from utils import header


def sum_to(n):
    """Add 1 + 2 + ... + n with an accumulator."""
    total = 0
    for i in range(1, n + 1):
        total += i
    return total


def factorial(n):
    """n! computed with a loop."""
    if n < 0:
        raise ValueError("factorial is not defined for negative numbers")
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


def fibonacci(count):
    """First `count` Fibonacci numbers using a while loop."""
    sequence = []
    a, b = 0, 1
    while len(sequence) < count:
        sequence.append(a)
        a, b = b, a + b
    return sequence


def is_prime(n):
    """Trial division up to the square root."""
    if n < 2:
        return False
    for divisor in range(2, int(n ** 0.5) + 1):
        if n % divisor == 0:
            return False
    return True


def collatz_steps(n):
    """Steps for n to reach 1 (halve if even, 3n+1 if odd)."""
    if n < 1:
        raise ValueError("n must be positive")
    steps = 0
    while n != 1:
        n = n // 2 if n % 2 == 0 else 3 * n + 1
        steps += 1
    return steps


def triangle(rows):
    """Right-angled triangle of stars (list of lines), built with a loop."""
    return ["*" * i for i in range(1, rows + 1)]


def multiplication_table(n, up_to=10):
    """Lines like '7 x 3 = 21'."""
    return [f"{n} x {i} = {n * i}" for i in range(1, up_to + 1)]


def perfect_numbers_below(limit):
    """Numbers below `limit` that equal the sum of their proper divisors (6, 28, ...)."""
    found = []
    for n in range(2, limit):
        divisor_total = 0
        for d in range(1, n // 2 + 1):
            if n % d == 0:
                divisor_total += d
        if divisor_total == n:
            found.append(n)
    return found


def pyramid(rows):
    """Centred pyramid of stars as a list of lines (no trailing spaces)."""
    return [" " * (rows - i) + "*" * (2 * i - 1) for i in range(1, rows + 1)]


def digit_sum(number):
    """Sum the digits of an integer using % and //."""
    number = abs(number)
    total = 0
    while number > 0:
        total += number % 10
        number //= 10
    return total


def demo():
    header("3. LOOPS: for, while, range, break, continue")

    print("for loop over a list, with enumerate:")
    for index, fruit in enumerate(["apple", "banana", "cherry"], start=1):
        print(f"  {index}. {fruit}")

    print("\nrange() variations:")
    print("  range(5)         ->", list(range(5)))
    print("  range(2, 10, 3)  ->", list(range(2, 10, 3)))
    print("  range(10, 0, -3) ->", list(range(10, 0, -3)))

    print("\nAccumulators:")
    print(f"  sum_to(100)   = {sum_to(100)}")
    print(f"  factorial(6)  = {factorial(6)}")
    print(f"  digit_sum(9875) = {digit_sum(9875)}")

    print("\nwhile loop: countdown")
    n = 5
    while n > 0:
        print(f"  {n}...", end="")
        n -= 1
    print(" liftoff!")

    print("\nFibonacci (while):", fibonacci(10))
    print("Collatz steps for 27:", collatz_steps(27))

    print("\ncontinue: print only odd numbers up to 10")
    print("  ", end="")
    for i in range(1, 11):
        if i % 2 == 0:
            continue
        print(i, end=" ")
    print()

    print("\nbreak with for/else: first prime after 90")
    for candidate in range(91, 200):
        if is_prime(candidate):
            print(f"  found {candidate}")
            break
    else:
        print("  none found")  # runs only if the loop never hit break

    print("\nNested loops: star triangle")
    for line in triangle(5):
        print("  " + line)

    print("\nNested loops: multiplication grid (1-5)")
    for row in range(1, 6):
        print("  " + "".join(f"{row * col:>4}" for col in range(1, 6)))

    print("\n7 times table:")
    for line in multiplication_table(7, 5):
        print("  " + line)


if __name__ == "__main__":
    demo()
