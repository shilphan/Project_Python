"""Python Basics Lab - run every topic demo from one menu.

Usage:
    python main.py          interactive menu
    python main.py --all    run every demo straight through
"""

import sys

import basics
import functions
import gradebook
import lists_demo
import loops
import matrix
import selection
import strings_demo
from utils import safe_input

MENU = [
    ("Basics", basics.demo),
    ("Selection statements", selection.demo),
    ("Loops", loops.demo),
    ("Functions", functions.demo),
    ("Lists", lists_demo.demo),
    ("Strings", strings_demo.demo),
    ("Multidimensional lists", matrix.demo),
    ("Capstone: Gradebook report", gradebook.demo),
]


def run_all():
    for _, demo in MENU:
        demo()


def print_menu():
    print("\n" + "=" * 40)
    print("        PYTHON BASICS LAB")
    print("=" * 40)
    for number, (title, _) in enumerate(MENU, start=1):
        print(f"  {number}. {title}")
    print("  a. Run everything")
    print("  g. Interactive gradebook")
    print("  0. Quit")


def main(argv):
    if "--all" in argv:
        run_all()
        return

    while True:
        print_menu()
        choice = (safe_input("Choose: ", "0") or "0").strip().lower()
        if choice in ("0", "q"):
            print("Happy coding!")
            break
        elif choice == "a":
            run_all()
        elif choice == "g":
            gradebook.interactive()
        elif choice.isdigit() and 1 <= int(choice) <= len(MENU):
            MENU[int(choice) - 1][1]()
        else:
            print("  Please pick a number from the menu.")


if __name__ == "__main__":
    main(sys.argv[1:])
