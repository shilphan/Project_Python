"""Topic 7 - Multidimensional lists: 2-D grids (matrices) and a 3-D example."""

from utils import header


def create_matrix(rows, cols, fill=0):
    """Build a rows x cols grid.

    Never write [[fill] * cols] * rows: that repeats the SAME inner list, so
    changing one row changes them all. A comprehension makes separate rows.
    """
    return [[fill for _ in range(cols)] for _ in range(rows)]


def pascal_triangle(rows):
    """First `rows` rows of Pascal's triangle as a list of lists (jagged 2-D list)."""
    triangle = []
    for r in range(rows):
        row = [1] * (r + 1)
        for c in range(1, r):
            row[c] = triangle[r - 1][c - 1] + triangle[r - 1][c]
        triangle.append(row)
    return triangle


def identity(n):
    """n x n identity matrix: 1s on the main diagonal, 0s elsewhere."""
    matrix = create_matrix(n, n)
    for i in range(n):
        matrix[i][i] = 1
    return matrix


def transpose(matrix):
    """Rows become columns."""
    return [[matrix[r][c] for r in range(len(matrix))] for c in range(len(matrix[0]))]


def row_sums(matrix):
    """Total of each row."""
    return [sum(row) for row in matrix]


def col_sums(matrix):
    """Total of each column."""
    return [sum(row[c] for row in matrix) for c in range(len(matrix[0]))]


def diagonal_sums(matrix):
    """(main diagonal, anti-diagonal) of a square matrix."""
    n = len(matrix)
    if any(len(row) != n for row in matrix):
        raise ValueError("matrix must be square")
    main = sum(matrix[i][i] for i in range(n))
    anti = sum(matrix[i][n - 1 - i] for i in range(n))
    return main, anti


def matrix_multiply(a, b):
    """Standard matrix product using three nested loops."""
    if len(a[0]) != len(b):
        raise ValueError("columns of a must equal rows of b")
    result = create_matrix(len(a), len(b[0]))
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                result[i][j] += a[i][k] * b[k][j]
    return result


def rotate_90_clockwise(matrix):
    """Rotate a grid a quarter turn clockwise."""
    return [list(row) for row in zip(*matrix[::-1])]


def flatten(matrix):
    """Turn a 2-D list into one flat list, row by row."""
    return [value for row in matrix for value in row]


def find_max(matrix):
    """Return (value, row, col) of the largest entry."""
    best = (matrix[0][0], 0, 0)
    for r, row in enumerate(matrix):
        for c, value in enumerate(row):
            if value > best[0]:
                best = (value, r, c)
    return best


def tic_tac_toe_winner(board):
    """Return 'X', 'O' or None for a 3x3 board of 'X', 'O' and ' '."""
    lines = []
    lines.extend(board)                                              # rows
    lines.extend([[board[r][c] for r in range(3)] for c in range(3)])  # columns
    lines.append([board[i][i] for i in range(3)])                    # diagonal
    lines.append([board[i][2 - i] for i in range(3)])                # anti-diagonal
    for line in lines:
        if line[0] != " " and line.count(line[0]) == 3:
            return line[0]
    return None


def format_matrix(matrix, indent="  "):
    """Right-aligned text grid, one line per row."""
    width = max(len(str(v)) for row in matrix for v in row)
    return "\n".join(indent + " ".join(f"{v:>{width}}" for v in row) for row in matrix)


def demo():
    header("7. MULTIDIMENSIONAL LISTS")

    grid = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
    ]
    print("A 2-D list is a list of lists:")
    print(format_matrix(grid))
    print(f"  grid[1][2] = {grid[1][2]}  (row 1, column 2)")
    print(f"  grid[0]    = {grid[0]}  (a whole row)")
    print(f"  len(grid)={len(grid)} rows, len(grid[0])={len(grid[0])} columns")

    print("\nTraversing with nested loops:")
    for r, row in enumerate(grid):
        for c, value in enumerate(row):
            if (r + c) % 2 == 0:
                print(f"  grid[{r}][{c}] = {value}")

    print("\nSums:")
    print(f"  row sums      {row_sums(grid)}")
    print(f"  column sums   {col_sums(grid)}")
    print(f"  diagonal sums {diagonal_sums(grid)}")

    print("\nTranspose:")
    print(format_matrix(transpose(grid)))
    print("Rotate 90 degrees clockwise:")
    print(format_matrix(rotate_90_clockwise(grid)))

    print("\nMatrix multiplication [[1,2],[3,4]] x [[5,6],[7,8]]:")
    print(format_matrix(matrix_multiply([[1, 2], [3, 4]], [[5, 6], [7, 8]])))
    print("Multiplying by the identity changes nothing:")
    print(format_matrix(matrix_multiply([[1, 2], [3, 4]], identity(2))))

    print(f"\nflatten -> {flatten(grid)}")
    print(f"find_max -> value, row, col = {find_max(grid)}")

    print("\nThe shared-row trap:")
    bad = [[0] * 3] * 2
    bad[0][0] = 9
    good = create_matrix(2, 3)
    good[0][0] = 9
    print(f"  [[0]*3]*2 then set [0][0]=9 -> {bad}  (both rows changed!)")
    print(f"  comprehension version       -> {good}")

    print("\nJagged (uneven) rows are allowed:")
    triangle = [[1], [1, 1], [1, 2, 1], [1, 3, 3, 1]]
    for row in triangle:
        print("  " + str(row).center(20))

    print("\nTic-tac-toe board:")
    board = [["X", "O", "X"],
             ["O", "X", "O"],
             [" ", " ", "X"]]
    print(format_matrix(board))
    print(f"  winner: {tic_tac_toe_winner(board)}")

    print("\nThree dimensions: 2 classes x 2 students x 3 test scores")
    school = [
        [[90, 85, 70], [60, 75, 80]],
        [[88, 92, 95], [55, 65, 70]],
    ]
    for c, klass in enumerate(school, start=1):
        for s, scores in enumerate(klass, start=1):
            print(f"  class {c}, student {s}: scores={scores} avg={sum(scores) / len(scores):.1f}")


if __name__ == "__main__":
    demo()
