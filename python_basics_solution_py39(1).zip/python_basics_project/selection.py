"""Topic 2 - Selection statements: if / elif / else, logical operators, membership tests."""

from utils import header


def grade_letter(score):
    """Convert a 0-100 score to a letter grade (if / elif / else chain)."""
    if not 0 <= score <= 100:
        raise ValueError("score must be between 0 and 100")
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


def is_leap_year(year):
    """Divisible by 4, except centuries, unless divisible by 400."""
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def classify_triangle(a, b, c):
    """Return 'invalid', 'equilateral', 'isosceles' or 'scalene'."""
    if a <= 0 or b <= 0 or c <= 0 or a + b <= c or a + c <= b or b + c <= a:
        return "invalid"
    if a == b == c:
        return "equilateral"
    if a == b or b == c or a == c:
        return "isosceles"
    return "scalene"


def bmi_category(bmi_value):
    """Standard adult BMI bands."""
    if bmi_value < 18.5:
        return "underweight"
    if bmi_value < 25:
        return "normal"
    if bmi_value < 30:
        return "overweight"
    return "obese"


def day_type(day):
    """Group a day name using membership tests (`in`).

    Python 3.10 added a `match` statement for this kind of job; it is avoided
    here so the whole project runs on Python 3.9.
    """
    name = day.strip().lower()
    if name in ("saturday", "sunday"):
        return "weekend"
    elif name in ("monday", "tuesday", "wednesday", "thursday", "friday"):
        return "weekday"
    else:
        return "unknown"


def ticket_price(age):
    """Child (under 13) 5, adult 10, senior (65 and over) 7; negative ages are invalid."""
    if age < 0:
        raise ValueError("age cannot be negative")
    if age < 13:
        return 5
    elif age >= 65:
        return 7
    else:
        return 10


def fizzbuzz_word(n):
    """The classic: Fizz for 3s, Buzz for 5s, FizzBuzz for both."""
    if n % 15 == 0:
        return "FizzBuzz"
    if n % 3 == 0:
        return "Fizz"
    if n % 5 == 0:
        return "Buzz"
    return str(n)


def demo():
    header("2. SELECTION: if / elif / else, and / or / not, in")

    print("Letter grades (if / elif / else):")
    for score in (95, 84, 71, 65, 40):
        print(f"  {score:>3} -> {grade_letter(score)}")

    print("\nLeap years (and / or / not):")
    for year in (1900, 2000, 2024, 2026):
        print(f"  {year}: {'leap' if is_leap_year(year) else 'not leap'}")  # ternary

    print("\nTriangles:")
    for sides in ((3, 3, 3), (3, 3, 5), (3, 4, 5), (1, 2, 8)):
        print(f"  {sides}: {classify_triangle(*sides)}")

    print("\nBMI bands:")
    for value in (17.0, 22.9, 27.5, 33.0):
        print(f"  {value}: {bmi_category(value)}")

    print("\nMembership tests with `in`:")
    for day in ("Saturday", "Wednesday", "Funday"):
        print(f"  {day}: {day_type(day)}")

    print("\nTicket prices by age:")
    for age in (8, 13, 40, 70):
        print(f"  age {age:>2}: {ticket_price(age)}")

    print("\nFizzBuzz 1-15:")
    print("  " + " ".join(fizzbuzz_word(n) for n in range(1, 16)))

    print("\nTruthiness: empty things are False")
    for item in ([], [0], "", "0", 0, None):
        print(f"  {item!r:<5} -> {'truthy' if item else 'falsy'}")


if __name__ == "__main__":
    demo()
