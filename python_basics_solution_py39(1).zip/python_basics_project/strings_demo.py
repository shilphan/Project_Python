"""Topic 6 - Strings: indexing, slicing, methods, formatting, text algorithms."""

import string

from utils import header


def is_palindrome(text):
    """Ignore case, spaces and punctuation."""
    cleaned = [ch.lower() for ch in text if ch.isalnum()]
    return cleaned == cleaned[::-1]


def count_vowels(text):
    """Number of vowels (a, e, i, o, u) in the text, ignoring case."""
    return sum(1 for ch in text.lower() if ch in "aeiou")


def strong_password(text):
    """True if the text has an upper-case letter, a lower-case letter, a digit and a symbol."""
    has_upper = any(ch.isupper() for ch in text)
    has_lower = any(ch.islower() for ch in text)
    has_digit = any(ch.isdigit() for ch in text)
    has_symbol = any(ch in string.punctuation for ch in text)
    return has_upper and has_lower and has_digit and has_symbol


def reverse_words(sentence):
    """'one two three' -> 'three two one'."""
    return " ".join(sentence.split()[::-1])


def caesar(text, shift):
    """Shift letters by `shift` places, leaving other characters alone."""
    result = []
    for ch in text:
        if ch.isalpha():
            base = ord("A") if ch.isupper() else ord("a")
            result.append(chr((ord(ch) - base + shift) % 26 + base))
        else:
            result.append(ch)
    return "".join(result)


def is_anagram(a, b):
    """True if both texts use the same letters, ignoring case, spaces and punctuation."""
    def letters(s):
        return sorted(ch.lower() for ch in s if ch.isalpha())
    return letters(a) == letters(b)


def word_frequency(text):
    """Case-insensitive word counts with punctuation stripped."""
    counts = {}
    for raw in text.split():
        word = raw.strip(string.punctuation).lower()
        if word:
            counts[word] = counts.get(word, 0) + 1
    return counts


def compress(text):
    """Run-length encoding: 'aaabbc' -> 'a3b2c1'."""
    if not text:
        return ""
    parts = []
    current, count = text[0], 1
    for ch in text[1:]:
        if ch == current:
            count += 1
        else:
            parts.append(f"{current}{count}")
            current, count = ch, 1
    parts.append(f"{current}{count}")
    return "".join(parts)


def capitalize_words(sentence):
    """Capitalise the first letter of every word: 'the quick fox' -> 'The Quick Fox'."""
    return " ".join(word.capitalize() for word in sentence.split())


def demo():
    header("6. STRINGS")

    s = "Hello, Python!"
    print(f"s = {s!r}")
    print(f"  s[0]={s[0]!r}  s[-1]={s[-1]!r}  s[7:13]={s[7:13]!r}  s[::-1]={s[::-1]!r}")
    print(f"  len(s) = {len(s)}   'Py' in s: {'Py' in s}")
    print("  Strings are immutable: s[0] = 'J' would raise TypeError")

    print("\nCommon methods:")
    print(f"  upper / lower / title: {s.upper()} | {s.lower()} | {s.title()}")
    print(f"  replace('Python','World'): {s.replace('Python', 'World')}")
    print(f"  find('o')={s.find('o')}  count('l')={s.count('l')}  find('z')={s.find('z')}")
    print(f"  startswith('Hell')={s.startswith('Hell')}  endswith('?')={s.endswith('?')}")
    print(f"  '  padded  '.strip() -> {'  padded  '.strip()!r}")
    print(f"  isdigit: '123'->{'123'.isdigit()}  'a1'->{'a1'.isdigit()}")

    print("\nsplit and join:")
    csv = "red,green,blue"
    parts = csv.split(",")
    print(f"  {csv!r}.split(',') -> {parts}")
    print(f"  ' | '.join(parts)  -> {' | '.join(parts)!r}")

    print("\nLooping over a string:")
    print("  ", [f"{i}:{ch}" for i, ch in enumerate("abc")])

    print("\nText algorithms:")
    print(f"  is_palindrome('A man, a plan, a canal: Panama') = "
          f"{is_palindrome('A man, a plan, a canal: Panama')}")
    print(f"  count_vowels('Programming')   = {count_vowels('Programming')}")
    print(f"  reverse_words('one two three') = {reverse_words('one two three')!r}")
    print(f"  caesar('Hello, World!', 3)     = {caesar('Hello, World!', 3)!r}")
    print(f"  caesar(..., -3) restores it    = {caesar(caesar('Hello, World!', 3), -3)!r}")
    print(f"  is_anagram('Listen','Silent')  = {is_anagram('Listen', 'Silent')}")
    print(f"  compress('aaabbbbc')           = {compress('aaabbbbc')!r}")
    print(f"  capitalize_words('the quick brown fox') = "
          f"{capitalize_words('the quick brown fox')!r}")

    text = "the cat and the hat and the bat"
    print(f"  word_frequency({text!r})")
    print("   ", word_frequency(text))

    print("\nFormatting a mini table:")
    for name, price in (("Tea", 2.5), ("Coffee", 3.75), ("Juice", 4.0)):
        print(f"  {name:<8}{price:>6.2f}")


if __name__ == "__main__":
    demo()
